import hashlib,hmac,os
from datetime import datetime,timezone
from fastapi import FastAPI,HTTPException,Depends,Header
from pydantic import BaseModel,Field
from sqlalchemy import create_engine,Column,Integer,String,Float,DateTime,ForeignKey
from sqlalchemy.orm import declarative_base,sessionmaker,Session

DB=os.getenv("DATABASE_URL","sqlite:///./recompensa.db")
SECRET=os.getenv("OFFER_WEBHOOK_SECRET","CHANGE_ME")
engine=create_engine(DB,connect_args={"check_same_thread":False} if DB.startswith("sqlite") else {})
SessionLocal=sessionmaker(bind=engine)
Base=declarative_base()

class User(Base):
    __tablename__="users"
    id=Column(Integer,primary_key=True)
    email=Column(String(255),unique=True,index=True)
    points=Column(Integer,default=0)

class OfferEvent(Base):
    __tablename__="offer_events"
    id=Column(Integer,primary_key=True)
    external_id=Column(String(255),unique=True,index=True)
    user_id=Column(Integer,ForeignKey("users.id"))
    provider=Column(String(50))
    revenue_usd=Column(Float,default=0)
    reward_points=Column(Integer,default=0)
    created_at=Column(DateTime,default=lambda:datetime.now(timezone.utc))

Base.metadata.create_all(engine)
app=FastAPI(title="Recompensa Monetization API",version="5.0.0")

def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()

class BitLabsCallback(BaseModel):
    event_id:str
    user_id:int
    payout_usd:float=Field(ge=0)
    reward_points:int=Field(ge=0)
    signature:str

@app.get("/health")
def health(): return {"ok":True,"version":"5.0.0"}

@app.post("/webhooks/bitlabs")
def bitlabs_callback(payload:BitLabsCallback,session:Session=Depends(db)):
    raw=f"{payload.event_id}:{payload.user_id}:{payload.payout_usd}:{payload.reward_points}"
    expected=hmac.new(SECRET.encode(),raw.encode(),hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected,payload.signature):
        raise HTTPException(401,"Firma inválida")
    if session.query(OfferEvent).filter_by(external_id=payload.event_id).first():
        return {"accepted":True,"duplicate":True}
    user=session.get(User,payload.user_id)
    if not user: raise HTTPException(404,"Usuario no encontrado")
    user.points += payload.reward_points
    session.add(OfferEvent(
        external_id=payload.event_id,user_id=user.id,provider="bitlabs",
        revenue_usd=payload.payout_usd,reward_points=payload.reward_points))
    session.commit()
    return {"accepted":True,"credited_points":payload.reward_points}

@app.get("/admin/monetization")
def monetization(session:Session=Depends(db)):
    events=session.query(OfferEvent).all()
    gross=sum(e.revenue_usd for e in events)
    points=sum(e.reward_points for e in events)
    # Modelo ilustrativo: 1000 puntos = $1 de coste de recompensa.
    reward_cost=points/1000
    return {"events":len(events),"gross_usd":round(gross,2),
            "reward_cost_usd":round(reward_cost,2),
            "gross_margin_before_other_costs":round(gross-reward_cost,2)}
