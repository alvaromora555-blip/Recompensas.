# Despliegue Recompensa

## A. Supabase
1. Crea un proyecto PostgreSQL.
2. Dashboard -> Connect.
3. Copia la cadena de conexión del **Session Pooler** si el entorno de despliegue necesita IPv4.
4. No publiques esa cadena.
5. La aplicación crea las tablas al iniciar.

## B. GitHub
Sube este directorio a un repositorio privado llamado `recompensa`.
No subas `.env` ni secretos.

## C. Render
1. En Render selecciona New -> Web Service.
2. Conecta el repositorio.
3. Puedes usar el `render.yaml` incluido.
4. Si configuras manualmente:
   Root Directory: `backend`
   Build: `pip install -r requirements.txt`
   Start: `uvicorn main:app --host 0.0.0.0 --port $PORT`
   Health Check: `/health`
5. Añade `DATABASE_URL`, `JWT_SECRET` y `OFFER_WEBHOOK_SECRET` como variables secretas.
6. Haz Deploy.

## D. Verificación
Cuando Render asigne la URL:
`https://TU-SERVICIO.onrender.com/health`

Debe devolver JSON con `ok: true`.

Swagger:
`https://TU-SERVICIO.onrender.com/docs`

## E. Android
En la app sustituye la URL local por:
`https://TU-SERVICIO.onrender.com`

No pongas DATABASE_URL ni secretos dentro de Android.

## F. Producción
- Cambiar IDs de prueba de AdMob por IDs propios.
- Configurar el proveedor de ofertas y callback HTTPS.
- Activar antifraude.
- Implementar pagos reales.
- Configurar privacidad/consentimiento.
- No usar la cuenta/demo ni secretos del repositorio.
