package com.recompensa.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.LoadAdError

private const val TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"

class MainActivity:ComponentActivity(){
    private var rewardedAd:RewardedAd?=null

    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this)
        loadRewarded()
        setContent{RecompensaScreen()}
    }

    private fun loadRewarded(){
        RewardedAd.load(this,TEST_REWARDED_AD_UNIT_ID,AdRequest.Builder().build(),
            object:RewardedAdLoadCallback(){
                override fun onAdLoaded(ad:RewardedAd){ rewardedAd=ad }
                override fun onAdFailedToLoad(error:LoadAdError){ rewardedAd=null }
            })
    }

    private fun showRewarded(){
        val ad=rewardedAd
        if(ad==null){
            Toast.makeText(this,"El anuncio todavía no está disponible",Toast.LENGTH_SHORT).show()
            loadRewarded()
            return
        }
        ad.show(this){ reward ->
            // En producción: enviar un evento firmado al backend/SSV.
            Toast.makeText(this,"Anuncio completado: ${reward.amount} ${reward.type}",Toast.LENGTH_SHORT).show()
        }
        rewardedAd=null
        loadRewarded()
    }

    @Composable
    fun RecompensaScreen(){
        var points by remember{mutableIntStateOf(120)}
        var status by remember{mutableStateOf("Anuncios de prueba activos.")}

        MaterialTheme{
            Scaffold(topBar={TopAppBar(title={Text("Recompensa 5.0")})}){pad->
                Column(Modifier.fillMaxSize().padding(pad).padding(20.dp),
                    verticalArrangement=Arrangement.spacedBy(14.dp)){
                    Card(Modifier.fillMaxWidth()){
                        Column(Modifier.padding(20.dp)){
                            Text("Tu saldo")
                            Text("$points puntos",style=MaterialTheme.typography.headlineMedium)
                            Text("Los anuncios actuales son de prueba y no generan ingresos.")
                        }
                    }
                    Button(onClick={
                        showRewarded()
                        status="Esperando confirmación del anuncio. El saldo real debe acreditarse en servidor."
                    },modifier=Modifier.fillMaxWidth()){
                        Text("Ver anuncio y ganar puntos")
                    }
                    OutlinedButton(onClick={
                        status="Offerwall: requiere configurar el App Token de BitLabs."
                    },modifier=Modifier.fillMaxWidth()){
                        Text("Encuestas y ofertas")
                    }
                    Text(status)
                }
            }
        }
    }
}
