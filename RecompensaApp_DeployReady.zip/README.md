# Recompensa 5.0 — Monetización integrada para pruebas

## Integraciones incluidas
### Google AdMob
- SDK Mobile Ads.
- Anuncio recompensado real en modo TEST.
- ID de prueba oficial de Google para Android:
  ca-app-pub-3940256099942544/5224354917
- El proyecto NO usa anuncios de producción todavía.

Google indica que durante desarrollo se deben usar anuncios de prueba y reemplazar el ID antes de publicar.

### BitLabs
Se deja una capa de integración para Offerwall.
BitLabs requiere crear una cuenta de publisher y obtener un App Token. También recomienda callbacks server-to-server para recompensas, especialmente cuando existe retiro de dinero.

## Qué debes configurar para producción
1. Crear cuenta AdMob.
2. Registrar la app y crear un ad unit ID recompensado.
3. Sustituir el TEST_REWARDED_AD_UNIT_ID por el ID real.
4. Crear cuenta BitLabs y obtener APP_TOKEN.
5. Configurar el callback S2S de BitLabs hacia `/webhooks/offers`.
6. Configurar HTTPS.
7. Cambiar secretos del backend.
8. Implementar retiro real (por ejemplo PayPal/otro proveedor disponible) y revisión antifraude.
9. Crear política de privacidad, términos y consentimiento.
10. Ejecutar pruebas cerradas de Google Play.

No se acredita dinero real por anuncios de prueba.

## Backend
    cd backend
    pip install -r requirements.txt
    export JWT_SECRET="CAMBIA_ESTA_CLAVE"
    export OFFER_WEBHOOK_SECRET="CAMBIA_ESTE_SECRETO"
    uvicorn main:app --host 0.0.0.0 --port 8000

## Android
Abrir la carpeta `android` en Android Studio y sincronizar Gradle.
